package myapp.ebank.service;

import com.fasterxml.jackson.databind.node.ObjectNode;
import myapp.ebank.model.dto.UserFundsAndLoans;
import myapp.ebank.model.entity.Funds;
import myapp.ebank.model.entity.Loans;
import myapp.ebank.model.entity.Roles;
import myapp.ebank.model.entity.Users;
import myapp.ebank.repository.LoanRepository;
import myapp.ebank.repository.UserRepository;
import myapp.ebank.util.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.text.ParseException;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.DoubleStream;
import java.util.stream.Stream;

/**
 * The type User service.
 */
@Service
public class UserService implements UserDetailsService {
    private static final Logger log = LogManager.getLogger(UserService.class);
    /**
     * The Loan repository.
     */
    final LoanRepository loanRepository;
    /**
     * The Feign police record service.
     */
    final FeignPoliceRecordService feignPoliceRecordService;
    private final UserRepository userRepository;
    private final EmailUtil emailUtil;
    private final SMSUtil smsUtil = new SMSUtil();
    private final Double interestRate = 0.045;
    private final Double loanAmount = 5000000.0;
    private final Double fundAmount = 10000000.0;
    private final BCryptPasswordEncoder bCryptPasswordEncoder;
    /**
     * The Unpaid loan count.
     */
    int unpaidLoanCount = 0;
    private Date expirationTime;


    /**
     * Instantiates a new User service.
     *
     * @param userRepository           the user repository
     * @param emailUtil                the email util
     * @param loanRepository           the loan repository
     * @param feignPoliceRecordService the feign police record service
     * @param bCryptPasswordEncoder    the b crypt password encoder
     */
// Autowiring through constructor
    public UserService(UserRepository userRepository, EmailUtil emailUtil, LoanRepository loanRepository, FeignPoliceRecordService feignPoliceRecordService, BCryptPasswordEncoder bCryptPasswordEncoder) {
        this.userRepository = userRepository;
        this.emailUtil = emailUtil;
        this.loanRepository = loanRepository;
        this.feignPoliceRecordService = feignPoliceRecordService;
        this.bCryptPasswordEncoder = bCryptPasswordEncoder;
    }


    /**
     * List all user response entity.
     *
     * @param requestUri the http servlet request uri
     * @return the response entity
     * @throws ParseException the parse exception
     */
    public ResponseEntity<Object> listAllUser(String  requestUri) throws ParseException {
        try {
            List<Users> users = userRepository.findAllByIsActiveOrderByCreatedDateDesc(true);
            // check if list is empty
            if (users.isEmpty()) {
                return new ResponseEntity<>(ResponseMapping.apiResponse(HttpStatus.NOT_FOUND, "  Users are empty", requestUri, null), HttpStatus.NOT_FOUND);
            } else {
                return new ResponseEntity<>(ResponseMapping.apiResponse(HttpStatus.OK, "users found", requestUri, users), HttpStatus.OK);
            }

        } catch (Exception e) {
            log.info("some error has occurred trying to Fetch users, in Class  UserService and its function listAllUser \t{} .... {}", e.getMessage(), e.getCause());
            return new ResponseEntity<>(ResponseMapping.apiResponse(HttpStatus.INTERNAL_SERVER_ERROR, "Some error occurred..Users could not be found",requestUri, null), HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    @Override
    public UserDetails loadUserByUsername(String userName) throws UsernameNotFoundException {
        Optional<Users> user = userRepository.findByUserName(userName);
        if (user.isPresent() && user.get().isActive()) {
            Set<GrantedAuthority> grantedAuthorities = new HashSet<>();
            for (Roles role : user.get().getRoles()) {
                grantedAuthorities.add(new SimpleGrantedAuthority(role.getName()));
                log.info("granted authorities are:  {}", role.getName());
            }
            log.info("granted authorities are:  {}", grantedAuthorities);

            return new User(user.get().getUserName(), user.get().getPassword(), grantedAuthorities);
        } else
            log.info("exception occurred in load by username parameter is {}", userName);
        throw new UsernameNotFoundException("user not found " + userName);
    }


    /**
     * Gets user by id.
     *
     * @param id                 the id
     * @param httpServletRequest the http servlet request
     * @return the user by id
     * @throws ParseException the parse exception
     */
    public ObjectNode getUserById(Long id, String  requestUri) throws ParseException {
        try {
            Optional<Users> user = userRepository.findByIdAndIsActive(id, true);
            if (user.isPresent()) {
                // check if user is verified
                log.info("user fetch and found from db by id  : {} ", user);
                return ResponseMapping.apiResponse(HttpStatus.OK, "user found",requestUri, user.get());
            } else {
                log.info("no user found with id:{}", id);
                return ResponseMapping.apiResponse(HttpStatus.NOT_FOUND, "could not found user with given details.... user may not be verified",requestUri, null);
            }
        } catch (Exception e) {
            e.printStackTrace();
            log.info(
                    "some error has occurred during fetching Users by id , in class UserService and its function getUserById {} .... {}", e.getMessage(), e.getCause());
            return ResponseMapping.apiResponse(HttpStatus.INTERNAL_SERVER_ERROR, "Some error occurred..Users could not be found",requestUri, null);

        }

    }


    /**
     * Save user response entity.
     *
     * @param user               the user
     * @param httpServletRequest the http servlet request
     * @return the response entity
     * @throws ParseException the parse exception
     */
    public ResponseEntity<Object> saveUser(Users user, String  requestUri) throws ParseException {
        try {
            //   Boolean criminalRecord = feignPoliceRecordService.checkCriminalRecord("61101-7896541-5");
            //  log.info("record is from kamran :" + criminalRecord);
            Date date = DateTime.getDateTime();
            expirationTime = DateTime.getExpireTime(2);
            user.setCreatedDate(date);
            user.setUpdatedDate(null);
            user.setActive(false);
            user.setPassword(bCryptPasswordEncoder.encode(user.getPassword()));
            Random rndkey = new Random(); // Generating a random number
            int token = rndkey.nextInt(999999); // Generating a random email token of 6 digits
            user.setToken(token);
            // save user to db
            userRepository.save(user);
            // send email token to user email and save in db
            emailUtil.sendMail(user.getEmail(), token);
            // send sms token to user email and save in db
            smsUtil.sendSMS(user.getPhoneNumber(), token);
            return new ResponseEntity<>(user, HttpStatus.OK);
        } catch (DataIntegrityViolationException e) {
            log.info("error is   {} .... {}", e.getMessage(), e.getCause());
            return new ResponseEntity<>(ResponseMapping.apiResponse(HttpStatus.BAD_REQUEST, e.getRootCause().getMessage(),requestUri, null), HttpStatus.NOT_ACCEPTABLE);
        } catch (Exception e) {
            log.info("some error has occurred while trying to save user,, in class UserService and its function saveUser {} .... {}", e.getMessage(), e.getCause());
            return new ResponseEntity<>(ResponseMapping.apiResponse(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage(),requestUri, null), HttpStatus.INTERNAL_SERVER_ERROR);

        }
    }

    /**
     * Update user response entity.
     *
     * @param user               the user
     * @param httpServletRequest the http servlet request
     * @return the response entity
     * @throws ParseException the parse exception
     */
    public ResponseEntity<Object> updateUser(Users user, String  requestUri) throws ParseException {
        HashMap<String, Object> responseMap = new HashMap<>();
        responseMap.put("userid", user.getId());
        responseMap.put("username", "fawad");
        try {
            user.setUpdatedDate(DateTime.getDateTime());
            userRepository.save(user);
            return new ResponseEntity<>(user, HttpStatus.OK);
        } catch (Exception e) {
            log.info(
                    "some error has occurred while trying to update user,, in class UserService and its function updateUser {} .... {}", e.getMessage(), e.getCause());
            return new ResponseEntity<>(ResponseMapping.apiResponse(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage(),requestUri, null), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Delete user response entity.
     *
     * @param id                 the id
     * @param httpServletRequest the http servlet request
     * @return the response entity
     * @throws ParseException the parse exception
     */
    public ResponseEntity<Object> deleteUser(Long id, String  requestUri) throws ParseException {
        try {
            Optional<Users> user = userRepository.findByIdAndIsActive(id, true);
            if (user.isPresent()) {
                // set status false
                user.get().setActive(false);
                // set updated date
                user.get().setUpdatedDate(DateTime.getDateTime());
                userRepository.save(user.get());
                return new ResponseEntity<>(ResponseMapping.apiResponse(HttpStatus.OK, "  Users deleted successfully",requestUri, null), HttpStatus.OK);

            } else
                return new ResponseEntity<>(ResponseMapping.apiResponse(HttpStatus.NOT_FOUND, "  Users does not exists ",requestUri, null), HttpStatus.OK);
        } catch (Exception e) {
            log.info(
                    "some error has occurred while trying to Delete user, in class UserService and its function deleteUser   {} .... {}", e.getMessage(), e.getCause());
            return new ResponseEntity<>(ResponseMapping.apiResponse(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage(),requestUri, null), HttpStatus.INTERNAL_SERVER_ERROR);

        }

    }

    /**
     * Verify user response entity.
     *
     * @param id                 the id
     * @param token              the token
     * @param httpServletRequest the http servlet request
     * @return the response entity
     * @throws ParseException the parse exception
     */
    public ResponseEntity<Object> verifyUser(Long id, int token, String  requestUri) throws ParseException {
        try {
            Optional<Users> user = userRepository.findByIdAndToken(id, token);
            Date date = DateTime.getDateTime();
            if (user.isPresent()) {
                //check if token is not expired
                if (date.after(expirationTime)) {
                    log.info("token has expired");
                    return new ResponseEntity<>("Token verification time has expire please regenerate verification token ", HttpStatus.METHOD_NOT_ALLOWED);
                }
                log.info("user is : {}", user);
                user.get().setActive(true);
                userRepository.save(user.get());
                return new ResponseEntity<>("user has been verified ", HttpStatus.OK);
            } else
                return new ResponseEntity<>("incorrect verification details were entered or verification time has expired", HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            log.info(String.valueOf(e.getCause()), e.getMessage());
            return new ResponseEntity<>(ResponseMapping.apiResponse(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage(),requestUri, null), HttpStatus.INTERNAL_SERVER_ERROR);

        }

    }

    /**
     * Send token response entity.
     *
     * @param id                 the id
     * @param httpServletRequest the http servlet request
     * @return the response entity
     * @throws ParseException the parse exception
     */
    public ResponseEntity<Object> sendToken(Long id, String  requestUri) throws ParseException {
        try {
            Optional<Users> user = userRepository.findById(id);
            if (user.isPresent()) {
                expirationTime = DateTime.getExpireTime(5);
                Random rndkey = new Random(); // Generating a random number
                int token = rndkey.nextInt(999999); // Generating a random email token of 6 digits
                user.get().setToken(token);
                userRepository.save(user.get());
                smsUtil.sendSMS(user.get().getPhoneNumber(), token);
                emailUtil.sendMail(user.get().getEmail(), token);
                return new ResponseEntity<>("token has been sent successfully please use it to verify ", HttpStatus.OK);
            } else {
                return new ResponseEntity<>("user not found", HttpStatus.NOT_FOUND);
            }
        } catch (Exception e) {
            log.info(
                    "some error has occurred during fetching User by id , in class UserService and its function sendSms  {} .... {}", e.getMessage(), e.getCause());
            return new ResponseEntity<>(ResponseMapping.apiResponse(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage(),requestUri, null), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Apply for loan response entity.
     *
     * @param id                 the id
     * @param loan               the loan
     * @param httpServletRequest the http servlet request
     * @return the response entity
     * @throws Exception the exception
     */
    public ResponseEntity<Object> applyForLoan(Long id, Loans loan, String  requestUri) throws Exception {
        try {
            if (loan.getLoanAmount() < loanAmount) {
                Optional<Users> user = userRepository.findById(id);
                if (user.isPresent() && user.get().isActive()) {
                    List<Loans> loans = new ArrayList<>(user.get().getLoans());
                    // count total unpaid loans of user
                    unpaidLoanCount = (int) loans.stream().filter(loans1 -> !loans1.getPaidStatus()).count();
                    if (unpaidLoanCount > 2) {
                        return new ResponseEntity<>("user has already pending unpaid loans", HttpStatus.METHOD_NOT_ALLOWED);
                    }

                    log.info("user fetch and found from db by id  {}: ", user);
                    loan.setCreatedDate(DateTime.getDateTime());
                    loan.setInterestRate(interestRate);
                    loan.setTotalAmountToBePaid(loan.getLoanAmount() + (interestRate * loan.getLoanAmount()));
                    loan.setDueDate(DateTime.getDueDate(5));
                    loan.setAmountPaid(0.0);
                    loan.setPaidStatus(false);
                    loan.setPaidDate(null);
                    loan.setActive(true);

                    loans.add(loan);
                    user.get().setLoans(loans);
                    // save loan to db first then save user
                    loanRepository.save(loan);
                    userRepository.save(user.get());
                    return new ResponseEntity<>(loan, HttpStatus.OK);
                } else {
                    log.info("no user found with id: {}", id);
                    return new ResponseEntity<>("could not found user with given details.... user may not be verified", HttpStatus.NOT_FOUND);
                }
            } else
                return new ResponseEntity<>("maximum allowed limit of loan is {loanAmount} ", HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            e.printStackTrace();
            log.info("an error has occurred in userService method apply for loan  {} .... {}", e.getMessage(), e.getCause());
            return new ResponseEntity<>(ResponseMapping.apiResponse(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage(),requestUri, null), HttpStatus.INTERNAL_SERVER_ERROR);

        }
    }

    /**
     * Deposit loan response entity.
     *
     * @param id                 the id
     * @param loan               the loan
     * @param httpServletRequest the http servlet request
     * @return the response entity
     * @throws ParseException the parse exception
     */
    public ResponseEntity<Object> depositLoan(Long id, Loans loan, String  requestUri) throws ParseException {

        try {
            Optional<Users> user = userRepository.findById(id);
            Optional<Loans> fetchUserLoans = loanRepository.findById(loan.getId());
            if (user.isPresent() && user.get().isActive() && fetchUserLoans.isPresent()) {
                List<Loans> loansList = new ArrayList<>(user.get().getLoans());

                for (Loans loan1 : loansList) {
                    // check if user contain  the loan specified
                    if (loan1.getId() == loan.getId() && !loan1.getPaidStatus()) {
                        double paidAmount = loan.getAmountPaid() - loan1.getTotalAmountToBePaid();
                        if (paidAmount > 0 || paidAmount < 0) {
                            return new ResponseEntity<>("paid amount is not equal to amount to be paid , please enter correct amount and try again", HttpStatus.FORBIDDEN);
                        }
                        if (Objects.equals(loan.getAmountPaid(), loan1.getTotalAmountToBePaid())) {
                            loan1.setPaidStatus(true);
                            loan1.setAmountPaid(loan.getAmountPaid());
                            loan1.setPaidDate(DateTime.getDateTime());
                            loanRepository.save(loan1);
                            return new ResponseEntity<>("loan paid successfully", HttpStatus.OK);
                        }
                    } else
                        return new ResponseEntity<>("loan could not be paid..it may have been paid already", HttpStatus.BAD_REQUEST);
                }
            } else if (fetchUserLoans.isEmpty()) {
                return new ResponseEntity<>("loans does not exist for given id", HttpStatus.BAD_REQUEST);
            }
            return new ResponseEntity<>("could not found any user record with given details.... user may not be verified", HttpStatus.BAD_REQUEST);

        } catch (
                Exception e) {
            log.info("an error has occurred in userService method depositLoan  {} .... {}", e.getMessage(), e.getCause());
            return new ResponseEntity<>(ResponseMapping.apiResponse(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage(),requestUri, null), HttpStatus.INTERNAL_SERVER_ERROR);

        }

    }

    /**
     * Apply for funds response entity.
     *
     * @param id                 the id
     * @param funds              the funds
     * @param httpServletRequest the http servlet request
     * @return the response entity
     * @throws ParseException the parse exception
     */
    public ResponseEntity<Object> applyForFunds(Long id, Funds funds, String  requestUri) throws ParseException {
        try {
            Optional<Users> user = userRepository.findById(id);
            if (user.isPresent() && user.get().isActive() && user.get().getOrganization().getType().equalsIgnoreCase("government")) {
                // check if user is  verified
                List<Funds> fundsList = new ArrayList<>(user.get().getFunds());
                if (funds.getAmount() > fundAmount) {
                    funds.setCreatedDate(DateTime.getDateTime());
                    funds.setApprovedStatus(false);
                    fundsList.add(funds);
                    user.get().setFunds(fundsList);
                    userRepository.save(user.get());
                    return new ResponseEntity<>(ResponseMapping.apiResponse(HttpStatus.OK, "Funds requested has been received..it will be process and its status will be updated soon",requestUri, null), HttpStatus.OK);

                }
                funds.setCreatedDate(DateTime.getDateTime());
                funds.setActive(true);
                funds.setApprovedStatus(true);
                fundsList.add(funds);
                user.get().setFunds(fundsList);
                userRepository.save(user.get());
                return new ResponseEntity<>(ResponseMapping.apiResponse(HttpStatus.OK, "funds has been approved ",requestUri, null), HttpStatus.OK);

            } else if (user.isPresent() && !user.get().getOrganization().getType().equalsIgnoreCase("government")) {
                return new ResponseEntity<>(ResponseMapping.apiResponse(HttpStatus.BAD_REQUEST, "only government departments can apply for funds",requestUri, null), HttpStatus.OK);
            } else
                return new ResponseEntity<>(ResponseMapping.apiResponse(HttpStatus.NOT_FOUND, "could not found user with given details.... user may not be verified",requestUri, null), HttpStatus.OK);

        } catch (
                Exception e) {
            log.info("error is {} .... {}", e.getMessage(), e.getCause());
            return new ResponseEntity<>(ResponseMapping.apiResponse(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage(),requestUri, null), HttpStatus.INTERNAL_SERVER_ERROR);

        }

    }

    /**
     * Gets user funds and loans.
     *
     * @param id                 the id
     * @param httpServletRequest the http servlet request
     * @return the user funds and loans
     * @throws ParseException the parse exception
     */
    public ResponseEntity<Object> getUserFundsAndLoans(Long id, String  requestUri) throws ParseException {
        try {
            Optional<Users> user = userRepository.findByIdAndIsActive(id, true);
            if (user.isPresent()) {
                // save Funds and Loans from user object
                UserFundsAndLoans userFundsAndLoans = new UserFundsAndLoans();
                userFundsAndLoans.setFunds(user.get().getFunds());
                userFundsAndLoans.setLoans(user.get().getLoans());
                return new ResponseEntity<>(ResponseMapping.apiResponse(HttpStatus.OK, "Success",requestUri, userFundsAndLoans), HttpStatus.OK);

            } else
                return new ResponseEntity<>(ResponseMapping.apiResponse(HttpStatus.NOT_FOUND, "user may not exists for given id",requestUri, null), HttpStatus.OK);

        } catch (Exception e) {
            log.info(
                    "some error has occurred during fetching User by id , in class UserService and its function getUserFundsAndLoans {} .... {}", e.getMessage(), e.getCause());
            return new ResponseEntity<>(ResponseMapping.apiResponse(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage(),requestUri, null), HttpStatus.INTERNAL_SERVER_ERROR);

        }
    }
}